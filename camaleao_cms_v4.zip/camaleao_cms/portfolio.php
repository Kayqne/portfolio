<?php
require __DIR__ . "/includes/config.php";
$data = cms_read_data($DATA_FILE);
?><!doctype html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Camaleão — Portfólio</title>
<link rel="stylesheet" href="assets/style.css">
<script defer src="assets/script.js"></script>
</head><body class="site">
<header class="sitebar">
  <div class="container bar__inner">
    <div class="brand">
      <img src="assets/images/logo-camaleao.svg" alt="Camaleão">
      <strong>CAMALEÃO</strong>
    </div>
    <nav><a class="btn ghost" href="admin/login.php">Painel</a></nav>
  </div>
</header>

<main class="container portfolio">
  <?php foreach($data["sections"] as $s): if(empty($s["published"])) continue; ?>
    <section class="site-section">
      <div class="site-head">
        <h2><?php echo htmlspecialchars($s["title"]); ?></h2>
        <p><?php echo htmlspecialchars($s["description"]); ?></p>
      </div>
      <div class="mosaic <?php echo htmlspecialchars($s["layout"]); ?>">
        <?php foreach($s["items"] as $it): if(empty($it["published"])) continue; ?>
          <a class="tile lightbox" href="<?php echo htmlspecialchars($it["src"]); ?>" data-type="<?php echo htmlspecialchars($it["type"]); ?>" title="<?php echo htmlspecialchars($it["caption"]); ?>">
            <?php if(($it["type"] ?? "image")==="video"): ?>
              <video src="<?php echo htmlspecialchars($it["src"]); ?>" autoplay loop muted playsinline></video>
            <?php else: ?>
              <img src="<?php echo htmlspecialchars($it["src"]); ?>" alt="">
            <?php endif; ?>
            <?php if(!empty($it["caption"])): ?><span class="cap"><?php echo htmlspecialchars($it["caption"]); ?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endforeach; if(empty(array_filter($data["sections"], fn($x)=>!empty($x["published"])))): ?>
    <div class="muted" style="padding:40px 0">Nenhuma seção publicada ainda.</div>
  <?php endif; ?>
</main>

<footer class="footer">
  <p>© 2025 Camaleão por Gabrielly Alves</p>
</footer>
</body></html>
