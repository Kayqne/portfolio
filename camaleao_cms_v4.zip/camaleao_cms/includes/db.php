<?php // JSON-based storage; abstraído em functions.php ?>
